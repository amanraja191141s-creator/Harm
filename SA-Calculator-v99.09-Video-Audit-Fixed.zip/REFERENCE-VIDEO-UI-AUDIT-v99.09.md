# SA Calculator v99.09 — video and source audit

## Sources inspected
- Tools reference recording: `Screenrecording_20261125_115925.mp4`
- Follow-up interaction recording: `Screenrecording_20261125_121746.mp4`
- Project source archive and synchronized Android workflow.

## Exact retained tools
- Finance & Money (8): GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount.
- Math & General Utilities (2): Percentage, Unit.
- Health (2): Age, BMI.
- Total: exactly 12 launchers. Unit conversion subcategories remain inside the Unit tool and are not separate launchers.

## Findings in follow-up recording
- BMI weight and height rows visibly overlap their labels/input areas and the unit controls.
- Age date-of-birth input is crowded into a single horizontal row with the label and placeholder.
- Shared keypad can obscure the currently selected numeric field when the field is below the visible viewport.
- Tool screens use a compact header and dark canvas; preserve existing navigation and visual language.
- The white transition frame near 60 seconds occurs during the Android date-picker interaction and is not, by itself, evidence of a persistent in-app blank-screen failure.

## Source-level fixes applied
- Dedicated responsive BMI field layout with readable dark input controls and separate unit switches.
- Dedicated two-row Age date-of-birth layout and full-width dark date input.
- Active numeric-field reveal above the shared keypad on click/focus.
- Preserved calculator engine, tool workspaces, shared keypad, favorites/search, and all 12 launchers.
- No additional launcher or unrelated feature introduced.

## Measured catalogue layout
- 3 equal columns.
- Cards: 98 CSS px height (90 CSS px on narrow/short viewports).
- Card radius: 14 CSS px.
- Grid gaps: 8 CSS px horizontal, 20 CSS px vertical.
- Icon viewport: 40 × 40 CSS px.
- Screen gutter: 12 CSS px.

## Verification limits
- 67/67 automated release/regression tests pass.
- JavaScript syntax checks pass.
- Android web bundle generated; source/www mirrors match byte-for-byte.
- ZIP integrity checked.
- Actual Android APK build and physical-device interaction/pixel validation remain to be run in GitHub Actions/on device.
