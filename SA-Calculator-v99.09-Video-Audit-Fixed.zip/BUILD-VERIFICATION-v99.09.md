# Build verification — SA Calculator v99.09 mobile form hotfix

- Release regression suite includes mobile form and keypad-visibility checks.
- BMI field layout and Age date input layout repaired.
- Active numeric field auto-reveals above the shared keypad.
- Web bundle rebuilt from authoritative source files.
- Android APK build and physical-device validation require GitHub Actions/device execution.
