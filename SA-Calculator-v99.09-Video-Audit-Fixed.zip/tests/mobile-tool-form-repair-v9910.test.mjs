import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
test('BMI weight and height controls use responsive stacked field layout',()=>{
 assert.match(css,/#screen-viewport #screen-bodymetrics \.bmi-reference-field\s*\{[^}]*display:flex/s);
 assert.match(css,/#screen-viewport #screen-bodymetrics \.bmi-reference-field-main\s*\{[^}]*display:grid/s);
 assert.match(html,/id="bmi-weight"/); assert.match(html,/id="bmi-height"/);
});
test('Age date input is laid out as a readable full-width dark control',()=>{
 assert.match(css,/#screen-viewport #screen-agecalc #age-date-of-birth\s*\{[^}]*width:100%/s);
 assert.match(css,/#screen-viewport #screen-agecalc \.age-dob-field\s*\{[^}]*display:grid/s);
});
test('active numeric input is scrolled above the shared keypad',()=>{
 assert.match(js,/revealActiveToolField/);
 assert.match(js,/tool-keypad-active/);
 assert.match(js,/scroller\.scrollBy/);
});
test('exact 12 tool launcher registry remains unchanged',()=>{
 const launchers=(html.match(/class="tool-launch-item"/g)||[]).length;
 assert.equal(launchers,12);
});
