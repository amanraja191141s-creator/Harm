# SA Calculator v99.09 — mobile tools hotfix

## Fixes
- Repaired BMI weight and height fields: proper stacked labels, readable dark input surfaces, consistent spacing, and responsive sizing.
- Repaired Age date-of-birth form: dedicated two-row layout, full-width date control, and readable dark-mode contrast.
- Added automatic reveal/scroll of the active numeric field above the shared keypad so the keypad does not obscure the selected field.
- Preserved all 12 requested tool launchers, all corresponding workspaces, existing calculation logic, favorites/search, and unit-converter categories.
- No new tool launchers or unrelated features were added.

## Validation
- 67/67 automated release/regression tests passed.
- Android web bundle generated successfully.
- Source and generated `www/` assets checked for byte-identical mirrors.
- ZIP integrity verified after packaging.
- Android APK compilation and physical-device verification remain external GitHub/device checks.
